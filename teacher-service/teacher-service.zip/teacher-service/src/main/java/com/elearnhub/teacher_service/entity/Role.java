package com.elearnhub.teacher_service.entity;

public enum Role {
    ADMIN,
    TEACHER,
    STUDENT
}
